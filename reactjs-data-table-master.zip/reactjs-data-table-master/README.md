# Reactjs-Data-Table

Uses ReactJS to Fetch GET data from an API and show that data in a Table.

Generated via Yoeman generator: generator-react-webpack

Uses Webpack to run tasks and local server (no Gulp or Grunt needed)

Fetches data using RESTful GET Call

Displays result in a HTML Table

UI:

- ReactJS 15.4.2
- Bootstrap 3.3.7
- Font-Awesome 4.7.0

Requirements:

- Node.js
- Git
- Webpack

To setup project read code_setup_instructions.txt