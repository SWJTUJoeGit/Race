var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "prod_tetools_v1_db"
});

con.connect(function (err) {
  if (err) throw err;
});

module.exports = con;