/*
-- Query: SELECT * FROM `Appointments`
LIMIT 0, 1000

-- Date: 2017-08-25 16:14
*/
INSERT INTO `Appointments` (`id`,`type`,`date`,`createdAt`,`updatedAt`,`patient_id`) VALUES (1,'Annual Visit','2017-09-10 17:00:00','2017-08-25 23:13:30','2017-08-25 23:13:30',NULL);
INSERT INTO `Appointments` (`id`,`type`,`date`,`createdAt`,`updatedAt`,`patient_id`) VALUES (2,'Follow-Up Visit','2017-09-10 18:00:00','2017-08-25 23:13:30','2017-08-25 23:13:30',NULL);
