/*
-- Query: SELECT * FROM `Users`
LIMIT 0, 1000

-- Date: 2017-08-25 16:13
*/
INSERT INTO `Users` (`id`,`email`,`password`,`type`,`createdAt`,`updatedAt`,`Patient_id`) VALUES (1,'bob@test.com','$2a$10$IRC7LEXe1nUr2/4JEZsng.Hss2Qq1BNjX.CHonNVjOnyf88XyKQOi','patient','2017-08-25 23:13:29','2017-08-25 23:13:29',1);
INSERT INTO `Users` (`id`,`email`,`password`,`type`,`createdAt`,`updatedAt`,`Patient_id`) VALUES (2,'eugene@test.com','$2a$10$ptJEn4/mz8hx3wCEsfY2LeVcZRF9rCq5y4.yu0pEF/MrXi6iuLVpW','patient','2017-08-25 23:13:29','2017-08-25 23:13:29',2);
INSERT INTO `Users` (`id`,`email`,`password`,`type`,`createdAt`,`updatedAt`,`Patient_id`) VALUES (3,'alberta@test.com','$2a$10$tFIGmL6swuHnOrPn6d87Uu0pRNVRrhlWOrXUAeT.2S86CKJPibY0a','patient','2017-08-25 23:13:29','2017-08-25 23:13:29',3);
INSERT INTO `Users` (`id`,`email`,`password`,`type`,`createdAt`,`updatedAt`,`Patient_id`) VALUES (4,'raymond@test.com','$2a$10$6Tu6CeGn2WIagpVnwo5Oq.1ai/6stePhFiC1DgU2/JmIllNTDUUtC','patient','2017-08-25 23:13:29','2017-08-25 23:13:29',4);
INSERT INTO `Users` (`id`,`email`,`password`,`type`,`createdAt`,`updatedAt`,`Patient_id`) VALUES (5,'deborah@test.com','$2a$10$0fHrAtmxOozMl/OW9LSXD.PlrJJ1rEXZ2qQzI.gkZj8N9VZ2Peyge','patient','2017-08-25 23:13:30','2017-08-25 23:13:30',5);
