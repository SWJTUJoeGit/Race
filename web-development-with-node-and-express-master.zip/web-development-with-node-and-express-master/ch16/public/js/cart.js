$(document).ready(function(){
	console.log('shopping cart initialized');
	// we would want to create our cart object here instead
	// of views/layouts/main.handlebars...
});
