$(document).ready(function(){
	console.log('contact forms initialized');
});
