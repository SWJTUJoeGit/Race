addpath(genpath(pwd));
fprintf('SSDH startup\n');
